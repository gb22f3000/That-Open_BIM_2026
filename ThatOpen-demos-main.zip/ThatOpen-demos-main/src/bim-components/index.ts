export * from "./CustomComponent";
