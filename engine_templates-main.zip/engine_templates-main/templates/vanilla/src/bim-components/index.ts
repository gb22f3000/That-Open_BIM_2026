export * from "./CustomComponent";
